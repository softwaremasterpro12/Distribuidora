package datos;

import dominio.Usuario;
import dominio.Validar;
import java.sql.*;
import java.util.*;

public class UsuarioDaoJDBC implements Validar {
    
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;

    @Override
    public int validar(Usuario usuario) {
        String sql = "SELECT * FROM usuario WHERE nombre=? AND contrasena=?";
        try {
            con = Conexion.getConecction();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getContrasena());
            rs = ps.executeQuery();
            
            while (rs.next()) {
                r = r + 1;
                usuario.setNombre(rs.getString("nombre"));
                usuario.setContrasena(rs.getString("contrasena"));
            }
            
            if (r == 1) {
                return 1;
            } else {
                return 0;
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            return 0;
        } finally {
            // Cierra aquí los recursos usando los métodos de Conexion
            Conexion.close(rs);
            Conexion.close(ps);
            Conexion.close(con);
        }
    }
}
