package dominio;

public class Usuario {
    private int idusuario;
    private String nombre;
    private String contrasena;
    private String tipo;
    
   public Usuario(){
       
   } 
    public Usuario(int idusuario){
       this.idusuario = idusuario;
   } 

    public Usuario( String nombre, String contrasena, String tipo) {
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.tipo = tipo;
    }

    public Usuario(int idusuario, String nombre, String contrasena, String tipo) {
        this.idusuario = idusuario;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.tipo = tipo;
    }

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Usuario{" + "idusuario=" + idusuario + ", nombre=" + nombre + ", contrasena=" + contrasena + ", tipo=" + tipo + '}';
    }
    
    
    
   
}
