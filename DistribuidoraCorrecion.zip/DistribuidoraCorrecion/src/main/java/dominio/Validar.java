package dominio;

public interface Validar {
   public int validar(Usuario usuario);
}
