package controlador;


import datos.UsuarioDaoJDBC;
import dominio.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/controlador")
public class controlador extends HttpServlet {
    UsuarioDaoJDBC user = new UsuarioDaoJDBC();
    Usuario usuario = new Usuario();
    int r;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        if (accion.equals("Ingresar")) {
            String nombre = request.getParameter("txtnom");
            String contrasena = request.getParameter("password");
            usuario.setNombre(nombre);
            usuario.setContrasena(contrasena);
            r = user.validar(usuario);
            if (r == 1) {
                // Si la validación es exitosa, puedes almacenar información en la sesión y redirigir a otra página.
                HttpSession session = request.getSession();
                session.setAttribute("usuario", usuario);
                request.getRequestDispatcher("Principal.jsp").forward(request, response);
            } else {
                // Si la validación no es exitosa, redirige a la página de inicio de sesión.
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}
